(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,33525,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"warnOnce",{enumerable:!0,get:function(){return o}});let o=e=>{}},18967,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={DecodeError:function(){return v},MiddlewareNotFoundError:function(){return E},MissingStaticPage:function(){return x},NormalizeError:function(){return y},PageNotFoundError:function(){return b},SP:function(){return g},ST:function(){return h},WEB_VITALS:function(){return a},execOnce:function(){return s},getDisplayName:function(){return d},getLocationOrigin:function(){return c},getURL:function(){return u},isAbsoluteUrl:function(){return l},isResSent:function(){return m},loadGetInitialProps:function(){return f},normalizeRepeatedSlashes:function(){return p},stringifyError:function(){return w}};for(var n in o)Object.defineProperty(r,n,{enumerable:!0,get:o[n]});let a=["CLS","FCP","FID","INP","LCP","TTFB"];function s(e){let t,r=!1;return(...o)=>(r||(r=!0,t=e(...o)),t)}let i=/^[a-zA-Z][a-zA-Z\d+\-.]*?:/,l=e=>i.test(e);function c(){let{protocol:e,hostname:t,port:r}=window.location;return`${e}//${t}${r?":"+r:""}`}function u(){let{href:e}=window.location,t=c();return e.substring(t.length)}function d(e){return"string"==typeof e?e:e.displayName||e.name||"Unknown"}function m(e){return e.finished||e.headersSent}function p(e){let t=e.split("?");return t[0].replace(/\\/g,"/").replace(/\/\/+/g,"/")+(t[1]?`?${t.slice(1).join("?")}`:"")}async function f(e,t){let r=t.res||t.ctx&&t.ctx.res;if(!e.getInitialProps)return t.ctx&&t.Component?{pageProps:await f(t.Component,t.ctx)}:{};let o=await e.getInitialProps(t);if(r&&m(r))return o;if(!o)throw Object.defineProperty(Error(`"${d(e)}.getInitialProps()" should resolve to an object. But found "${o}" instead.`),"__NEXT_ERROR_CODE",{value:"E1025",enumerable:!1,configurable:!0});return o}let g="u">typeof performance,h=g&&["mark","measure","getEntriesByName"].every(e=>"function"==typeof performance[e]);class v extends Error{}class y extends Error{}class b extends Error{constructor(e){super(),this.code="ENOENT",this.name="PageNotFoundError",this.message=`Cannot find module for page: ${e}`}}class x extends Error{constructor(e,t){super(),this.message=`Failed to load static file for page: ${e} ${t}`}}class E extends Error{constructor(){super(),this.code="ENOENT",this.message="Cannot find the middleware module"}}function w(e){return JSON.stringify({message:e.message,stack:e.stack})}},98183,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={assign:function(){return l},searchParamsToUrlQuery:function(){return a},urlQueryToSearchParams:function(){return i}};for(var n in o)Object.defineProperty(r,n,{enumerable:!0,get:o[n]});function a(e){let t={};for(let[r,o]of e.entries()){let e=t[r];void 0===e?t[r]=o:Array.isArray(e)?e.push(o):t[r]=[e,o]}return t}function s(e){return"string"==typeof e?e:("number"!=typeof e||isNaN(e))&&"boolean"!=typeof e?"":String(e)}function i(e){let t=new URLSearchParams;for(let[r,o]of Object.entries(e))if(Array.isArray(o))for(let e of o)t.append(r,s(e));else t.set(r,s(o));return t}function l(e,...t){for(let r of t){for(let t of r.keys())e.delete(t);for(let[t,o]of r.entries())e.append(t,o)}return e}},18566,(e,t,r)=>{t.exports=e.r(76562)},43549,e=>{"use strict";var t=e.i(43476),r=e.i(71645);let o={fr:{"nav.dashboard":"Tableau de bord","nav.products":"Produits","nav.stock":"Stock","nav.purchases":"Achats","nav.sales_detail":"Vente Détail","nav.sales_gros":"Vente Gros","nav.orders":"Commandes Live","nav.historique":"Historique commandes","nav.hr":"Ressources Humaines","nav.payments":"Paiements","nav.clients":"Clients","nav.fournisseurs":"Fournisseurs","nav.my_orders":"Mes Commandes","nav.order_detail":"Commande Détail","nav.order_gros":"Commande Gros","nav.stock_view":"Stock produits","nav.my_clients":"Mes Clients","nav.deliveries":"Mes Livraisons","nav.history":"Historique","nav.logout":"Déconnexion","nav.comptes":"Gestion Comptes","common.search":"Rechercher...","common.add":"Ajouter","common.edit":"Modifier","common.delete":"Supprimer","common.save":"Enregistrer","common.cancel":"Annuler","common.confirm":"Confirmer","common.total":"Total","common.actions":"Actions","common.status":"Statut","common.date":"Date","common.loading":"Chargement...","common.close":"Fermer","common.submit":"Soumettre","common.yes":"Oui","common.no":"Non","status.en_attente":"En attente","status.confirmee":"Confirmée","status.en_livraison":"En livraison","status.livree":"Livrée","status.annulee":"Annulée","status.brouillon":"Brouillon","status.recu":"Reçu","dash.total_sales":"Ventes ce mois","dash.stock_value":"Valeur du stock","dash.pending_orders":"Commandes en attente","dash.clients":"Clients","dash.low_stock":"Stock faible","dash.revenue_chart":"Évolution des ventes (7 jours)","prod.name":"Nom du produit","prod.code":"Code","prod.unit":"Unité","prod.price_detail":"Prix Détail","prod.price_gros":"Prix Gros","prod.stock":"Stock actuel","prod.min_stock":"Stock minimum","login.title":"Connexion","login.username":"Nom d'utilisateur","login.password":"Mot de passe","login.btn":"Se connecter","login.subtitle":"Gestion Distribution Détergents"},ar:{"nav.dashboard":"لوحة التحكم","nav.products":"المنتجات","nav.stock":"المخزون","nav.purchases":"المشتريات","nav.sales_detail":"بيع تجزئة","nav.sales_gros":"بيع جملة","nav.orders":"الطلبات المباشرة","nav.historique":"سجل الطلبات","nav.hr":"الموارد البشرية","nav.payments":"المدفوعات","nav.clients":"العملاء","nav.fournisseurs":"الموردون","nav.my_orders":"طلباتي","nav.order_detail":"طلب تجزئة","nav.order_gros":"طلب جملة","nav.stock_view":"المخزون المتاح","nav.my_clients":"عملائي","nav.deliveries":"توصيلاتي","nav.history":"السجل","nav.logout":"تسجيل الخروج","nav.comptes":"إدارة الحسابات","common.search":"بحث...","common.add":"إضافة","common.edit":"تعديل","common.delete":"حذف","common.save":"حفظ","common.cancel":"إلغاء","common.confirm":"تأكيد","common.total":"المجموع","common.actions":"الإجراءات","common.status":"الحالة","common.date":"التاريخ","common.loading":"جارٍ التحميل...","common.close":"إغلاق","common.submit":"إرسال","common.yes":"نعم","common.no":"لا","status.en_attente":"في الانتظار","status.confirmee":"مؤكد","status.en_livraison":"قيد التوصيل","status.livree":"تم التوصيل","status.annulee":"ملغى","status.brouillon":"مسودة","status.recu":"مستلم","dash.total_sales":"مبيعات الشهر","dash.stock_value":"قيمة المخزون","dash.pending_orders":"الطلبات المعلقة","dash.clients":"العملاء","dash.low_stock":"مخزون منخفض","dash.revenue_chart":"تطور المبيعات (7 أيام)","prod.name":"اسم المنتج","prod.code":"الرمز","prod.unit":"الوحدة","prod.price_detail":"سعر التجزئة","prod.price_gros":"سعر الجملة","prod.stock":"المخزون الحالي","prod.min_stock":"الحد الأدنى","login.title":"تسجيل الدخول","login.username":"اسم المستخدم","login.password":"كلمة المرور","login.btn":"دخول","login.subtitle":"إدارة توزيع المنظفات"}},n=(0,r.createContext)(null);e.s(["LangProvider",0,function({children:e}){let[a,s]=(0,r.useState)("fr");return(0,r.useEffect)(()=>{let e=localStorage.getItem("lang");e&&s(e)},[]),(0,r.useEffect)(()=>{document.documentElement.dir="ar"===a?"rtl":"ltr",document.documentElement.lang=a},[a]),(0,t.jsx)(n.Provider,{value:{lang:a,setLang:e=>{s(e),localStorage.setItem("lang",e),document.documentElement.dir="ar"===e?"rtl":"ltr",document.documentElement.lang=e},isRTL:"ar"===a,t:e=>o[a][e]||e},children:e})},"useLang",0,function(){let e=(0,r.useContext)(n);if(!e)throw Error("useLang must be used within LangProvider");return e}])},75144,e=>{"use strict";var t=e.i(43476),r=e.i(71645);let o=(0,r.createContext)(null);e.s(["ThemeProvider",0,function({children:e}){let[n,a]=(0,r.useState)("light");return(0,r.useEffect)(()=>{let e=localStorage.getItem("theme");e?(a(e),document.documentElement.setAttribute("data-theme",e)):document.documentElement.setAttribute("data-theme","light")},[]),(0,t.jsx)(o.Provider,{value:{theme:n,toggleTheme:()=>{let e="light"===n?"dark":"light";a(e),localStorage.setItem("theme",e),document.documentElement.setAttribute("data-theme",e)}},children:e})},"useTheme",0,function(){let e=(0,r.useContext)(o);if(!e)throw Error("useTheme must be used within ThemeProvider");return e}])},5766,e=>{"use strict";let t,r;var o,n=e.i(71645);let a={data:""},s=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,i=/\/\*[^]*?\*\/|  +/g,l=/\n+/g,c=(e,t)=>{let r="",o="",n="";for(let a in e){let s=e[a];"@"==a[0]?"i"==a[1]?r=a+" "+s+";":o+="f"==a[1]?c(s,a):a+"{"+c(s,"k"==a[1]?"":t)+"}":"object"==typeof s?o+=c(s,t?t.replace(/([^,])+/g,e=>a.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):a):null!=s&&(a="-"==a[1]?a:a.replace(/[A-Z]/g,"-$&").toLowerCase(),n+=c.p?c.p(a,s):a+":"+s+";")}return r+(t&&n?t+"{"+n+"}":n)+o},u={},d=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+d(e[r]);return t}return e};function m(e){let t,r,o=this||{},n=e.call?e(o.p):e;return((e,t,r,o,n)=>{var a;let m=d(e),p=u[m]||(u[m]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(m));if(!u[p]){let t=m!==e?e:(e=>{let t,r,o=[{}];for(;t=s.exec(e.replace(i,""));)t[4]?o.shift():t[3]?(r=t[3].replace(l," ").trim(),o.unshift(o[0][r]=o[0][r]||{})):o[0][t[1]]=t[2].replace(l," ").trim();return o[0]})(e);u[p]=c(n?{["@keyframes "+p]:t}:t,r?"":"."+p)}let f=r&&u.g;return r&&(u.g=u[p]),a=u[p],f?t.data=t.data.replace(f,a):-1===t.data.indexOf(a)&&(t.data=o?a+t.data:t.data+a),p})(n.unshift?n.raw?(t=[].slice.call(arguments,1),r=o.p,n.reduce((e,o,n)=>{let a=t[n];if(a&&a.call){let e=a(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;a=t?"."+t:e&&"object"==typeof e?e.props?"":c(e,""):!1===e?"":e}return e+o+(null==a?"":a)},"")):n.reduce((e,t)=>Object.assign(e,t&&t.call?t(o.p):t),{}):n,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||a})(o.target),o.g,o.o,o.k)}m.bind({g:1});let p,f,g,h=m.bind({k:1});function v(e,t){let r=this||{};return function(){let o=arguments;function n(a,s){let i=Object.assign({},a),l=i.className||n.className;r.p=Object.assign({theme:f&&f()},i),r.o=/go\d/.test(l),i.className=m.apply(r,o)+(l?" "+l:""),t&&(i.ref=s);let c=e;return e[0]&&(c=i.as||e,delete i.as),g&&c[0]&&g(i),p(c,i)}return t?t(n):n}}var y=(e,t)=>"function"==typeof e?e(t):e,b=(t=0,()=>(++t).toString()),x=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},E="default",w=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:o}=t;return w(e,{type:+!!e.toasts.find(e=>e.id===o.id),toast:o});case 3:let{toastId:n}=t;return{...e,toasts:e.toasts.map(e=>e.id===n||void 0===n?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},_=[],k={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},C={},P=(e,t=E)=>{C[t]=w(C[t]||k,e),_.forEach(([e,r])=>{e===t&&r(C[t])})},S=e=>Object.keys(C).forEach(t=>P(e,t)),O=(e=E)=>t=>{P(t,e)},T={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},N=(e={},t=E)=>{let[r,o]=(0,n.useState)(C[t]||k),a=(0,n.useRef)(C[t]);(0,n.useEffect)(()=>(a.current!==C[t]&&o(C[t]),_.push([t,o]),()=>{let e=_.findIndex(([e])=>e===t);e>-1&&_.splice(e,1)}),[t]);let s=r.toasts.map(t=>{var r,o,n;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(o=e[t.type])?void 0:o.duration)||(null==e?void 0:e.duration)||T[t.type],style:{...e.style,...null==(n=e[t.type])?void 0:n.style,...t.style}}});return{...r,toasts:s}},j=e=>(t,r)=>{let o,n=((e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||b()}))(t,e,r);return O(n.toasterId||(o=n.id,Object.keys(C).find(e=>C[e].toasts.some(e=>e.id===o))))({type:2,toast:n}),n.id},A=(e,t)=>j("blank")(e,t);A.error=j("error"),A.success=j("success"),A.loading=j("loading"),A.custom=j("custom"),A.dismiss=(e,t)=>{let r={type:3,toastId:e};t?O(t)(r):S(r)},A.dismissAll=e=>A.dismiss(void 0,e),A.remove=(e,t)=>{let r={type:4,toastId:e};t?O(t)(r):S(r)},A.removeAll=e=>A.remove(void 0,e),A.promise=(e,t,r)=>{let o=A.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let n=t.success?y(t.success,e):void 0;return n?A.success(n,{id:o,...r,...null==r?void 0:r.success}):A.dismiss(o),e}).catch(e=>{let n=t.error?y(t.error,e):void 0;n?A.error(n,{id:o,...r,...null==r?void 0:r.error}):A.dismiss(o)}),e};var $=1e3,I=(e,t="default")=>{let{toasts:r,pausedAt:o}=N(e,t),a=(0,n.useRef)(new Map).current,s=(0,n.useCallback)((e,t=$)=>{if(a.has(e))return;let r=setTimeout(()=>{a.delete(e),i({type:4,toastId:e})},t);a.set(e,r)},[]);(0,n.useEffect)(()=>{if(o)return;let e=Date.now(),n=r.map(r=>{if(r.duration===1/0)return;let o=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(o<0){r.visible&&A.dismiss(r.id);return}return setTimeout(()=>A.dismiss(r.id,t),o)});return()=>{n.forEach(e=>e&&clearTimeout(e))}},[r,o,t]);let i=(0,n.useCallback)(O(t),[t]),l=(0,n.useCallback)(()=>{i({type:5,time:Date.now()})},[i]),c=(0,n.useCallback)((e,t)=>{i({type:1,toast:{id:e,height:t}})},[i]),u=(0,n.useCallback)(()=>{o&&i({type:6,time:Date.now()})},[o,i]),d=(0,n.useCallback)((e,t)=>{let{reverseOrder:o=!1,gutter:n=8,defaultPosition:a}=t||{},s=r.filter(t=>(t.position||a)===(e.position||a)&&t.height),i=s.findIndex(t=>t.id===e.id),l=s.filter((e,t)=>t<i&&e.visible).length;return s.filter(e=>e.visible).slice(...o?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+n,0)},[r]);return(0,n.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)s(e.id,e.removeDelay);else{let t=a.get(e.id);t&&(clearTimeout(t),a.delete(e.id))}})},[r,s]),{toasts:r,handlers:{updateHeight:c,startPause:l,endPause:u,calculateOffset:d}}},D=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,L=h`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,M=h`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,R=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${D} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${L} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${M} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,z=h`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,F=v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${z} 1s linear infinite;
`,U=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,B=h`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,H=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${B} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,G=v("div")`
  position: absolute;
`,V=v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,q=h`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Z=v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${q} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,K=({toast:e})=>{let{icon:t,type:r,iconTheme:o}=e;return void 0!==t?"string"==typeof t?n.createElement(Z,null,t):t:"blank"===r?null:n.createElement(V,null,n.createElement(F,{...o}),"loading"!==r&&n.createElement(G,null,"error"===r?n.createElement(R,{...o}):n.createElement(H,{...o})))},Q=v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,J=v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,W=n.memo(({toast:e,position:t,style:r,children:o})=>{let a=e.height?((e,t)=>{let r=e.includes("top")?1:-1,[o,n]=x()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*r}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*r}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${h(o)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${h(n)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},s=n.createElement(K,{toast:e}),i=n.createElement(J,{...e.ariaProps},y(e.message,e));return n.createElement(Q,{className:e.className,style:{...a,...r,...e.style}},"function"==typeof o?o({icon:s,message:i}):n.createElement(n.Fragment,null,s,i))});o=n.createElement,c.p=void 0,p=o,f=void 0,g=void 0;var X=({id:e,className:t,style:r,onHeightUpdate:o,children:a})=>{let s=n.useCallback(t=>{if(t){let r=()=>{o(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,o]);return n.createElement("div",{ref:s,className:t,style:r},a)},Y=m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;e.s(["CheckmarkIcon",0,H,"ErrorIcon",0,R,"LoaderIcon",0,F,"ToastBar",0,W,"ToastIcon",0,K,"Toaster",0,({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:o,children:a,toasterId:s,containerStyle:i,containerClassName:l})=>{let{toasts:c,handlers:u}=I(r,s);return n.createElement("div",{"data-rht-toaster":s||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:l,onMouseEnter:u.startPause,onMouseLeave:u.endPause},c.map(r=>{let s,i,l=r.position||t,c=u.calculateOffset(r,{reverseOrder:e,gutter:o,defaultPosition:t}),d=(s=l.includes("top"),i=l.includes("center")?{justifyContent:"center"}:l.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:x()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${c*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...i});return n.createElement(X,{id:r.id,key:r.id,onHeightUpdate:u.updateHeight,className:r.visible?Y:"",style:d},"custom"===r.type?y(r.message,r):a?a(r):n.createElement(W,{toast:r,position:l}))}))},"default",0,A,"resolveValue",0,y,"toast",0,A,"useToaster",0,I,"useToasterStore",0,N],5766)}]);